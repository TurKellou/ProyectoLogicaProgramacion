<?php 
// Incluir la conexión y la cabecera
require_once 'includes/conexion.php'; 
require_once 'includes/header.php'; 
?>

<div class="row align-items-center mb-5">
    <div class="col-lg-6">
        <h1 class="display-4 fw-bold text-primary">Aprende lógica programando soluciones reales</h1>
        <p class="lead text-muted mt-3">Plataforma didáctica para la retroalimentación del aprendizaje de Algoritmos de Programación mediante ejercicios aplicados a problemas cotidianos.</p>
        <div class="d-grid gap-2 d-md-flex justify-content-md-start mt-4">
            <a href="modulos/ejercicios/index.php" class="btn btn-primary btn-lg px-4 me-md-2">Empezar a practicar</a>
            <a href="modulos/teoria/index.php" class="btn btn-outline-secondary btn-lg px-4">Revisar teoría</a>
        </div>
    </div>
    <div class="col-lg-6 mt-4 mt-lg-0 text-center">
        <div class="p-5 bg-secondary text-white rounded-3 shadow">
            <h2>&lt;/&gt;</h2>
            <p>Visualiza el análisis, desarrolla el pseudocódigo y codifica la solución.</p>
        </div>
    </div>
</div>

<div class="row g-4 mt-4">
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0">
            <div class="card-body text-center">
                <h4 class="card-title text-primary">Contenidos Claros</h4>
                <p class="card-text">Revisa teoría resumida sobre variables, estructuras de control, POO y bases de datos.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0">
            <div class="card-body text-center">
                <h4 class="card-title text-primary">Casos Reales</h4>
                <p class="card-text">Ejercicios paso a paso basados en cálculo de sueldos, inventarios y promedios académicos.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0">
            <div class="card-body text-center">
                <h4 class="card-title text-primary">Feedback Inmediato</h4>
                <p class="card-text">Ingresa tus respuestas y obtén retroalimentación automática sobre tu lógica.</p>
            </div>
        </div>
    </div>
</div>

<?php 
// Incluir el pie de página
require_once 'includes/footer.php'; 
?>
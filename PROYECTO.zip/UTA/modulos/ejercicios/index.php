<?php
require_once '../../includes/conexion.php';
require_once '../../includes/header.php';

// Consultamos los ejercicios disponibles
$stmt = $pdo->query("SELECT e.*, t.NombreTema FROM Ejercicio e JOIN Tema t ON e.IdTema = t.IdTema ORDER BY e.Dificultad ASC");
$ejercicios = $stmt->fetchAll();
?>

<div class="text-center mb-5">
    <h1 class="display-5 fw-bold text-primary">Laboratorio de Prácticas</h1>
    <p class="lead text-muted">Elige cómo quieres poner a prueba tu lógica hoy.</p>
</div>

<div class="row g-4">
    <?php foreach ($ejercicios as $ej): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm hover-shadow transition">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <span class="badge bg-info text-dark"><?php echo htmlspecialchars($ej['Categoria']); ?></span>
                        <small class="text-muted"><i class="bi bi-bar-chart"></i> <?php echo $ej['Dificultad']; ?></small>
                    </div>
                    <h5 class="fw-bold"><?php echo htmlspecialchars($ej['Titulo']); ?></h5>
                    <p class="text-muted small"><?php echo substr(htmlspecialchars($ej['Enunciado']), 0, 100); ?>...</p>
                </div>
                <div class="card-footer bg-transparent border-0 d-grid gap-2 pb-3">
                    <a href="practica.php?id=<?php echo $ej['IdEjercicio']; ?>" class="btn btn-primary shadow-sm">
                        <i class="bi bi-calculator"></i> Práctica con Datos
                    </a>
                    <a href="pseudocodigo.php?id=<?php echo $ej['IdEjercicio']; ?>" class="btn btn-outline-success shadow-sm">
                        <i class="bi bi-code-slash"></i> Desafío de Pseudocódigo
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<style>
    .hover-shadow:hover { transform: translateY(-5px); box-shadow: 0 1rem 3rem rgba(0,0,0,.1) !important; }
    .transition { transition: all 0.3s ease; }
</style>

<?php require_once '../../includes/footer.php'; ?>
<?php
require_once '../../includes/conexion.php';
require_once '../../includes/header.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<div class='alert alert-danger mt-5'>Ejercicio inválido.</div>";
    require_once '../../includes/footer.php';
    exit();
}

$idEjercicio = $_GET['id'];

$sql = "SELECT e.*, t.NombreTema FROM Ejercicio e INNER JOIN Tema t ON e.IdTema = t.IdTema WHERE e.IdEjercicio = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$idEjercicio]);
$ejercicio = $stmt->fetch();

if (!$ejercicio) {
    echo "<div class='alert alert-warning mt-5'>El ejercicio solicitado no existe.</div>";
    require_once '../../includes/footer.php';
    exit();
}
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        
        <a href="index.php" class="btn btn-sm btn-outline-secondary mb-4">&larr; Volver al Listado</a>
        
        <div class="card shadow border-0 mb-4">
            <div class="card-header bg-success text-white p-4">
                <span class="badge bg-white text-success mb-2">Tema: <?php echo htmlspecialchars($ejercicio['NombreTema']); ?></span>
                <h2 class="fw-bold mb-0"><?php echo htmlspecialchars($ejercicio['Titulo']); ?></h2>
            </div>
            <div class="card-body p-4 p-md-5">
                
                <h4 class="fw-bold border-bottom pb-2">El Problema</h4>
                <p class="fs-5 text-dark mb-5"><?php echo htmlspecialchars($ejercicio['Enunciado']); ?></p>

                <div class="bg-light p-4 rounded-3 border">
                    <h4 class="fw-bold text-success mb-4"><i class="bi bi-lightbulb"></i> Solución Propuesta</h4>
                    
                    <div class="solucion-contenido">
                        <?php echo $ejercicio['SolucionEsperada']; ?>
                    </div>
                </div>

            </div>
            <div class="card-footer bg-white p-4 text-center">
                <p class="text-muted mb-3">¿Entendiste la lógica de este ejercicio?</p>
                <a href="../ejercicios/index.php" class="btn btn-primary">Ir a Prácticas Interactivas</a>
            </div>
        </div>

    </div>
</div>

<style>
/* Estilo rápido para que el bloque de código se vea más didáctico */
.solucion-contenido pre {
    background-color: #2d2d2d;
    color: #f8f8f2;
    padding: 15px;
    border-radius: 5px;
    font-size: 1.1rem;
}
</style>

<?php require_once '../../includes/footer.php'; ?>